from app.ingestion.loader import load_data
from app.validator.rule_validator import validate_schema, fix_datatypes
from app.healer.rule_healer import *
from app.healer.retry_engine import run_retry_loop
from app.config.schema import EXPECTED_SCHEMA
from app.config.settings import OUTPUT_DIR, PIPELINE_NAME
from app.utils.logger import Logger
from app.output.writer import write_outputs
from app.output.report import print_report


def run_pipeline(input_path):

    logger = Logger(PIPELINE_NAME)

    df = load_data(input_path)

    df = validate_schema(df, EXPECTED_SCHEMA, logger)
    df, _ = fix_datatypes(df, EXPECTED_SCHEMA, logger)

    df = heal_missing_values(df, logger)
    df = heal_invalid_telemetry(df, logger)
    df = remove_duplicates(df, logger)

    df = run_retry_loop(df, EXPECTED_SCHEMA, logger)

    csv, log = write_outputs(df, logger.get_logs(), OUTPUT_DIR)

    print_report(df, logger.get_logs())

    return csv, log