from datetime import datetime

class Logger:
    def __init__(self, name):
        self.name = name
        self.logs = []

    def log(self, issue, column, record, action, status, remarks):
        self.logs.append({
            "timestamp": str(datetime.now()),
            "pipeline": self.name,
            "issue": issue,
            "column": column,
            "record": record,
            "action": action,
            "status": status,
            "remarks": remarks
        })

    def get_logs(self):
        return self.logs