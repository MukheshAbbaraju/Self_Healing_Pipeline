import os, json

def write_outputs(df, logs, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    csv_path = os.path.join(output_dir, "cleaned.csv")
    log_path = os.path.join(output_dir, "logs.json")

    df.to_csv(csv_path, index=False)

    with open(log_path, "w") as f:
        json.dump(logs, f, indent=2)

    return csv_path, log_path