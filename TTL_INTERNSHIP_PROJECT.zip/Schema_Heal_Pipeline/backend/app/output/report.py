def print_report(df, logs):

    print("\n" + "=" * 60)
    print("✅ SELF-HEALING PIPELINE REPORT")
    print("=" * 60)

    # Dataset Info
    print("\n📊 Dataset Summary:")
    print(f"Rows: {len(df)}")
    print(f"Columns: {len(df.columns)}")

    # Null check
    nulls = df.isnull().sum().sum()
    print(f"Null values: {nulls}")

    # Duplicate check
    duplicates = df.duplicated(
        subset=["vehicle_id", "timestamp"]
    ).sum()
    print(f"Duplicate records: {duplicates}")

    # Schema
    print("\n📌 Columns:")
    for col in df.columns:
        print(f" - {col}")

    # Logs Summary
    print("\n📌 Issues handled:")
    if logs:
        from collections import Counter
        counter = Counter([log["issue"] for log in logs])

        for issue, count in counter.items():
            print(f"{issue}: {count}")
    else:
        print("No issues detected")

    print("\n✅ FINAL STATUS: PASSED")
    print("=" * 60 + "\n")