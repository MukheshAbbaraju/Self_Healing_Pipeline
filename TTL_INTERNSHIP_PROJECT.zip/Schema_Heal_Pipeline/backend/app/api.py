from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import os
import shutil
import uuid
import traceback
import json

from lang import run_pipeline, run_pipeline_stream

app = FastAPI(title="Self-Healing Data Pipeline API")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_OUTPUT_DIR = "output"
os.makedirs(BASE_OUTPUT_DIR, exist_ok=True)


# RUN PIPELINE (NORMAL)
@app.post("/run-pipeline")
def run_self_healing_pipeline(file: UploadFile = File(...)):
    try:
        print("Received file:", file.filename)

        run_id = str(uuid.uuid4())
        run_dir = os.path.join(BASE_OUTPUT_DIR, run_id)
        os.makedirs(run_dir, exist_ok=True)

        input_path = os.path.join(run_dir, file.filename)

        with open(input_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        print("File saved at:", input_path)

        result = run_pipeline(input_path, run_dir)

        print("Pipeline completed")

        return {
            "run_id": run_id,
            "status": "success",
            "summary": result["summary"]
        }

    except Exception as e:
        print("PIPELINE CRASHED")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))



# REAL-TIME STREAMING PIPELINE (NEW)
@app.post("/run-pipeline-stream")
def run_pipeline_stream_api(file: UploadFile = File(...),prompt: str = ""):
    try:
        print("Streaming pipeline started:", file.filename)

        run_id = str(uuid.uuid4())
        run_dir = os.path.join(BASE_OUTPUT_DIR, run_id)
        os.makedirs(run_dir, exist_ok=True)

        input_path = os.path.join(run_dir, file.filename)

        with open(input_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        print("File saved:", input_path)

        # Streaming generator
        def event_stream():
            try:
                for event in run_pipeline_stream(input_path, run_dir,prompt):

                    # attach run_id in final event
                    if event.get("type") == "done":
                        event["run_id"] = run_id

                    yield json.dumps(event) + "\n"

            except Exception as e:
                yield json.dumps({
                    "type": "error",
                    "message": str(e)
                }) + "\n"

        return StreamingResponse(event_stream(), media_type="text/plain")

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))



# DOWNLOAD FILES

@app.get("/download/clean/{run_id}")
def download_clean(run_id: str):
    path = os.path.join(BASE_OUTPUT_DIR, run_id, "clean_data.csv")

    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Clean data not found")

    return FileResponse(path, filename="clean_data.csv")


@app.get("/download/healed/{run_id}")
def download_healed(run_id: str):
    path = os.path.join(BASE_OUTPUT_DIR, run_id, "healed_rows.csv")

    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Healed rows not found")

    return FileResponse(path, filename="healed_rows.csv")


@app.get("/logs/{run_id}")
def download_logs(run_id: str):
    path = os.path.join(BASE_OUTPUT_DIR, run_id, "healing_log.json")

    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Logs not found")

    return FileResponse(path, filename="healing_log.json")


# HISTORY

@app.get("/history")
def get_history():
    runs = [
        d for d in os.listdir(BASE_OUTPUT_DIR)
        if os.path.isdir(os.path.join(BASE_OUTPUT_DIR, d))
    ]
    runs.sort(reverse=True)
    return {"runs": runs}

# SUMMARY

@app.get("/summary/{run_id}")
def get_summary(run_id: str):
    path = os.path.join(BASE_OUTPUT_DIR, run_id, "summary.json")

    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Summary not found")

    with open(path) as f:
        summary = json.load(f)

    return {"summary": summary}
