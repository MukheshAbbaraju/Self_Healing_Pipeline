MAX_RETRIES = 3
PIPELINE_NAME = "vehicle_pipeline"
OUTPUT_DIR = "data/output"
UPLOAD_DIR = "temp_uploads"