EXPECTED_SCHEMA = {
    "vehicle_id": "string",
    "timestamp": "datetime",
    "speed": "float",
    "soc": "float",
    "voltage": "float",
    "current": "float",
    "temperature": "float",
    "latitude": "float",
    "longitude": "float"
}
