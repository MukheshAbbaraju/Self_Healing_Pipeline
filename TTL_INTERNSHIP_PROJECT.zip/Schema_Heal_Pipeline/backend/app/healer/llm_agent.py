from langchain_google_genai import ChatGoogleGenerativeAI
import json

llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-pro",
    temperature=0
)

def llm_heal(issues, schema):
    prompt = f"""
Fix data issues.

Schema: {schema}
Issues: {issues}

Return ONLY JSON:
{{
  "column_mapping": {{}},
  "fixes": []
}}"""

    response = llm.invoke(prompt)

    try:
        return json.loads(response.content)
    except:
        return {"column_mapping": {}, "fixes": []}