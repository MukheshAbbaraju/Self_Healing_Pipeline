def apply_llm_fixes(df, fixes):
    if "column_mapping" in fixes:
        df.rename(columns=fixes["column_mapping"], inplace=True)
    return df