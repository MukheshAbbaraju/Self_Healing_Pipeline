def heal_missing_values(df, logger):
    for col in df.columns:
        if df[col].isnull().any():
            df[col] = df[col].ffill().fillna(0)
            logger.log("missing_value", col, "rows", "filled", "success", "")
    return df


def heal_invalid_telemetry(df, logger):
    df["speed"] = df["speed"].clip(lower=0)
    df["soc"] = df["soc"].clip(0, 100)
    df["temperature"] = df["temperature"].clip(-40, 120)
    df["latitude"] = df["latitude"].clip(-90, 90)
    df["longitude"] = df["longitude"].clip(-180, 180)
    return df


def remove_duplicates(df, logger):
    before = len(df)
    df.sort_values("timestamp", inplace=True)
    df = df.drop_duplicates(["vehicle_id", "timestamp"], keep="last")

    removed = before - len(df)
    if removed:
        logger.log("duplicate", "vehicle_id+timestamp", "dataset", f"{removed}_removed", "success", "")

    return df