from validator.pydantic_validator import validate_with_pydantic
from .llm_agent import llm_heal
from .apply_fixes import apply_llm_fixes
from config.settings import MAX_RETRIES

def run_retry_loop(df, schema, logger):
    for i in range(MAX_RETRIES):
        errors = validate_with_pydantic(df)

        if not errors:
            return df

        logger.log("retry", "", "", f"attempt_{i+1}", "running", "")

        fixes = llm_heal(errors, schema)
        df = apply_llm_fixes(df, fixes)

    return df