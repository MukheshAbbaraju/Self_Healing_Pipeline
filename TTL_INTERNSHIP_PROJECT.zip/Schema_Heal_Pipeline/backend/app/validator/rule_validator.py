import pandas as pd

def validate_schema(df, expected_schema, logger):
    incoming = set(df.columns)
    expected = set(expected_schema.keys())

    for col in incoming - expected:
        df.drop(columns=[col], inplace=True)
        logger.log("unexpected_column", col, "schema", "dropped", "success", "")

    for col in expected - incoming:
        df[col] = None
        logger.log("missing_column", col, "schema", "created", "success", "")

    return df[list(expected_schema.keys())]


def fix_datatypes(df, expected_schema, logger):
    for col, dtype in expected_schema.items():
        if dtype == "float":
            df[col] = pd.to_numeric(df[col], errors="coerce")
        elif dtype == "datetime":
            df[col] = pd.to_datetime(df[col], errors="coerce")
        elif dtype == "string":
            df[col] = df[col].astype(str)

    return df, []