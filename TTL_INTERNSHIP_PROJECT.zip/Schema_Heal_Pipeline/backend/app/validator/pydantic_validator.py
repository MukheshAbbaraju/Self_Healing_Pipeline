from .pydantic_model import TelemetryRecord

def validate_with_pydantic(df):
    errors = []

    for i, row in df.iterrows():
        try:
            TelemetryRecord(**row.to_dict())
        except Exception as e:
            errors.append({"row": i, "error": str(e)})

    return errors