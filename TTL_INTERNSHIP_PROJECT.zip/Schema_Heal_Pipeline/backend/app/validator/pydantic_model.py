from pydantic import BaseModel, Field
from datetime import datetime

class TelemetryRecord(BaseModel):
    vehicle_id: str
    timestamp: datetime
    speed: float = Field(ge=0)
    soc: float = Field(ge=0, le=100)
    voltage: float
    current: float
    temperature: float = Field(ge=-40, le=120)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)