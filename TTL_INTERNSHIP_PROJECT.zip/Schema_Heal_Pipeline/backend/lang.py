import os
import json
from typing import Dict, Any, List, Generator
import pandas as pd

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser

# SCHEMA & RULES

EXPECTED_SCHEMA: Dict[str, str] = {
    "vehicle_id": "string",
    "timestamp": "string",
    "speed": "float",
    "soc": "float",
    "voltage": "float",
    "current": "float",
    "temperature": "float",
    "latitude": "float",
    "longitude": "float",
}

RANGE_RULES = {
    "speed": (0, 300),
    "soc": (0, 100),
    "temperature": (-50, 150),
    "latitude": (-90, 90),
    "longitude": (-180, 180),
}

SCHEMA_COLS: List[str] = list(EXPECTED_SCHEMA.keys())


# LLM SETUP


if not os.getenv("GOOGLE_API_KEY"):
    raise EnvironmentError("GOOGLE_API_KEY is not set")

llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-pro",
    temperature=0,
    streaming=True,
)

prompt = PromptTemplate.from_template("""
You are a strict data cleaning engine.

Fix this telemetry row to match schema.

Schema:
{schema}

Row:
{row}
                                      
Additional user instruction:
{user_instruction}

Return STRICT JSON ONLY:
{{
  "fixed_record": {{
    "vehicle_id": "",
    "timestamp": "",
    "speed": 0,
    "soc": 0,
    "voltage": 0,
    "current": 0,
    "temperature": 0,
    "latitude": 0,
    "longitude": 0
  }},
  "issues_detected": [],
  "fixes_applied": [],
  "healed": true
}}
""")

parser = JsonOutputParser()
chain = prompt | llm | parser

# RULE CLEANING

def basic_clean(df: pd.DataFrame):
    for col in SCHEMA_COLS:
        if col not in df.columns:
            df[col] = None

    df = df[SCHEMA_COLS]

    for col in SCHEMA_COLS:
        if col == "vehicle_id":
            df[col] = df[col].astype(str)
        elif col == "timestamp":
            df[col] = pd.to_datetime(df[col], errors="coerce")
        else:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.ffill().fillna(0)

    for col, (low, high) in RANGE_RULES.items():
        df[col] = df[col].clip(lower=low, upper=high)

    df = df.drop_duplicates(["vehicle_id", "timestamp"], keep="last")

    return df

# LLM HEAL

def heal_row(row: pd.Series, user_prompt: str = ""):
    try:
        full_prompt = {
            "row": row.to_dict(),
            "schema": EXPECTED_SCHEMA,
            "user_instruction": user_prompt  # ✅ NEW
        }

        result = chain.invoke(full_prompt)
        return result

    except Exception:
        return fallback(row)


def fallback(row):
    return {
        "fixed_record": row.to_dict(),
        "issues_detected": [],
        "fixes_applied": [],
        "healed": False
    }
def run_pipeline(input_path: str, output_dir: str):

    df = pd.read_csv(input_path)

    logs = []
    final_rows = []
    healed_rows = []

    df = basic_clean(df)

    for idx, row in df.iterrows():

        result = heal_row(row)

        if result.get("healed", False):

            fixed = result["fixed_record"]

            final_rows.append(fixed)
            healed_rows.append(fixed)

            logs.append({
                "row_index": int(idx),
                "vehicle_id": row.get("vehicle_id", ""),
                "issues_detected": result.get("issues_detected", []),
                "fixes_applied": result.get("fixes_applied", [])
            })

        else:
            final_rows.append(row.to_dict())

    final_df = pd.DataFrame(final_rows)
    final_df = basic_clean(final_df)

    os.makedirs(output_dir, exist_ok=True)

    clean_path = os.path.join(output_dir, "clean_data.csv")
    healed_path = os.path.join(output_dir, "healed_rows.csv")
    log_path = os.path.join(output_dir, "healing_log.json")
    summary_path = os.path.join(output_dir, "summary.json")

    final_df.to_csv(clean_path, index=False)
    pd.DataFrame(healed_rows).to_csv(healed_path, index=False)

    summary = {
        "total_rows": len(final_df),
        "healed_rows": len(logs),
        "quarantined_rows": 0
    }

    with open(log_path, "w") as f:
        json.dump(logs, f, indent=2)

    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    return {"summary": summary}


# STREAMING PIPELINE
def run_pipeline_stream(input_path: str, output_dir: str,user_prompt: str = "") -> Generator:

    df = pd.read_csv(input_path)

    logs = []
    final_rows = []
    healed_rows = []

    yield {"type": "log", "message": "Dataset loaded"}

    df = basic_clean(df)
    yield {"type": "log", "message": "Rule-based cleaning done"}

    total = len(df)

    for idx, row in df.iterrows():

        result = heal_row(row, user_prompt)

        if result.get("healed", False):

            fixed = result["fixed_record"]

            final_rows.append(fixed)
            healed_rows.append(fixed)

            log_entry = {
                "row_index": int(idx),
                "vehicle_id": row.get("vehicle_id", ""),
                "issues_detected": result.get("issues_detected", []),
                "fixes_applied": result.get("fixes_applied", [])
            }

            logs.append(log_entry)

            # STREAM EVENT
            yield {
                "type": "row_fix",
                "row": int(idx),
                "message": f"Row {idx} healed",
                "details": log_entry
            }

        else:
            final_rows.append(row.to_dict())

        # PROGRESS UPDATE
        yield {
            "type": "progress",
            "progress": int((idx + 1) / total * 100)
        }

    final_df = pd.DataFrame(final_rows)
    final_df = basic_clean(final_df)

    os.makedirs(output_dir, exist_ok=True)

    clean_path = os.path.join(output_dir, "clean_data.csv")
    healed_path = os.path.join(output_dir, "healed_rows.csv")
    log_path = os.path.join(output_dir, "healing_log.json")
    summary_path = os.path.join(output_dir, "summary.json")

    final_df.to_csv(clean_path, index=False)
    pd.DataFrame(healed_rows).to_csv(healed_path, index=False)

    summary = {
        "total_rows": len(final_df),
        "healed_rows": len(logs),
        "quarantined_rows": 0
    }

    with open(log_path, "w") as f:
        json.dump(logs, f, indent=2)

    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    yield {"type": "done", "summary": summary}