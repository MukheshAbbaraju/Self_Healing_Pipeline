from app.main import run_pipeline

if __name__ == "__main__":
    run_pipeline("temp_uploads/sample.csv")