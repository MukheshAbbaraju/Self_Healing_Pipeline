import { useState, useRef, useEffect } from "react";
import "./ModelDropdown.css";
const models = [
  "Gemini 3.5 Flash",
  "Gemini 2.5 Pro",
  "Gemini 1.5 Flash",
  "Gemini 3 Flash"
];

export default function ModelDropdown({ value, onChange }: any) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef<HTMLDivElement | null>(null);

  const filtered = models.filter((m) =>
    m.toLowerCase().includes(search.toLowerCase())
  );

  useEffect(() => {
    const handleClickOutside = (e: any) => {
      if (ref.current && !ref.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="dropdown" ref={ref}>

      <div
        className="dropdown-button"
        onClick={() => setOpen((prev) => !prev)}
      >
        {value}
      </div>

      {/* MENU */}
      <div className={`dropdown-menu ${open ? "open" : ""}`}>
        {/* SEARCH */}
        <input
          className="dropdown-search"
          placeholder="Search model..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          autoFocus
        />

        {/* OPTIONS */}
        {filtered.map((m) => (
          <div
            key={m}
            className={`dropdown-item ${value === m ? "active" : ""}`}
            onClick={() => {
              onChange(m);
              setOpen(false);
              setSearch("");
            }}
          >
            {m}
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="dropdown-empty">No models</div>
        )}
      </div>

    </div>
  );
}