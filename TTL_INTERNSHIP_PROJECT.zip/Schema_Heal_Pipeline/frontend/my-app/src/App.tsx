import { useRef, useState, useEffect } from "react";
import axios from "axios";
import "./App.css";
import ModelDropdown from "./ModelDropDown.tsx";

import runIcon from "./assets/run.png";
import uploadIcon from "./assets/upload.png";
import logoIcon from "./assets/menu.png";
import homeIcon from "./assets/home.png";
import newIcon from "./assets/new.png";
import historyIcon from "./assets/history.png";
import docsIcon from "./assets/docs.png";
import account_icon from "./assets/account_icon.png";

const API_BASE = "http://127.0.0.1:8000";

export default function App() {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState("");
  const [runId, setRunId] = useState<string | null>(null);
  const [summary, setSummary] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>([]);

  const [logs, setLogs] = useState<string[]>([]);
  const [progress, setProgress] = useState(0); 

  const [expanded, setExpanded] = useState(false);
  const [activeMenu, setActiveMenu] = useState<"home" | "history" | "docs" | "account" |null>(null);
  const [userPrompt, setUserPrompt] = useState("");
  const [model, setModel] = useState("Gemini 2.5 Pro");


  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const res = await axios.get(`${API_BASE}/history`);
      setHistory(res.data.runs);
    } catch {
      console.log("Failed to fetch history");
    }
  };

  const loadRun = async (id: string) => {
    try {
      const res = await axios.get(`${API_BASE}/summary/${id}`);

      setRunId(id);
      setSummary(res.data.summary);
      setStatus("");
      setError(null);
      setExpanded(true);
      setActiveMenu("history");

    } catch {
      console.log("Failed to load run");
    }
  };

  // STREAMING PIPELINE (REPLACES axios POST)
  const runPipeline = async () => {
    if (!file) {
      setError("Please upload a CSV file.");
      return;
    }

    setStatus("Running...");
    setError(null);
    setSummary(null);
    setLogs([]);       
    setProgress(0);     

    const formData = new FormData();
    formData.append("file", file);
    formData.append("prompt", userPrompt);
    formData.append("model", model);

    try {
      const res = await fetch(`${API_BASE}/run-pipeline-stream`, {
        method: "POST",
        body: formData,
      });

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader!.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split("\n");

        lines.forEach((line) => {
          if (!line.trim()) return;

          const event = JSON.parse(line);

          // LOGS
          if (event.type === "log") {
            setLogs((prev) => [...prev, event.message]);
          }

          //ROW FIX
          if (event.type === "row_fix") {
            setLogs((prev) => [
              ...prev,
              `Row ${event.row} healed`
            ]);
          }

          // PROGRESS
          if (event.type === "progress") {
            setProgress(event.progress);
          }

          // DONE
          if (event.type === "done") {
            setSummary(event.summary);
            setStatus("Completed");
            setRunId(event.run_id || null);
            fetchHistory();
          }
        });
      }

    } catch (err: any) {
      setStatus("");
      setError("Streaming failed");
    }
  };

  const download = (type: "clean" | "healed" | "logs") => {
    if (!runId) return;

    const url =
      type === "logs"
        ? `${API_BASE}/logs/${runId}`
        : `${API_BASE}/download/${type}/${runId}`;

    window.open(url);
  };

  const removeFile = () => {
    setFile(null);
    setRunId(null);
    setSummary(null);
    setStatus("");
    setError(null);
    setLogs([]);
    setProgress(0);  

    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  return (
    <div className="app-layout">

      {/* SIDEBAR */}
      <div className={`sidebar ${expanded ? "expanded" : ""}`}>

        <div
          className="sidebar-item"
          onClick={() => setExpanded(!expanded)}
        >
          <img src={logoIcon} className="icon" />
          {expanded && <span>Pipeline</span>}
        </div>

        <div className="sidebar-section">
          <div
            className={`sidebar-item ${activeMenu === "home" ? "active" : ""}`}
            data-label="Home"
            onClick={() => {
              window.location.reload();
            }}
          >

            <img src={homeIcon} className="icon" />
            {expanded && <span>Home</span>}
          </div>

          <div
            className="sidebar-item"
            onClick={() => {
              setExpanded(true);
              setActiveMenu(null);
              removeFile();
            }}
          >
            <img src={newIcon} className="icon" />
            {expanded && <span>New</span>}
          </div>

          <div
            className={`sidebar-item ${activeMenu === "history" ? "active" : ""}`}
            onClick={() => {
              setExpanded(true);
              setActiveMenu("history");
            }}
          >
            <img src={historyIcon} className="icon" />
            {expanded && <span>History</span>}
          </div>

          <div
            className={`sidebar-item ${activeMenu === "docs" ? "active" : ""}`}
            onClick={() => {
              setExpanded(true);
              setActiveMenu("docs");
            }}
          >
            <img src={docsIcon} className="icon" />
            {expanded && <span>Docs</span>}
          </div>
          <div
            className={`sidebar-item ${activeMenu === "account" ? "active" : ""}`}
            onClick={() => {
              setExpanded(true);
              setActiveMenu("account");
            }}
          >
            <img src={account_icon} className="account_icon" />
            {expanded && <span>Account</span>}
          </div>
        </div>

        {expanded && activeMenu === "history" && (
          <div className="sidebar-subsection">
            <div className="divider" />
            <p className="sidebar-title">Runs</p>

            {history.map((id) => (
              <div
                key={id}
                className={`history-item ${runId === id ? "active" : ""}`}
                onClick={() => loadRun(id)}
              >
                {id.slice(0, 8)}
              </div>
            ))}
          </div>
        )}

      </div>

      {/* MAIN */}
      <div className="main">

        <h1 className="title">Self‑Healing Pipeline</h1>

        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          className="hidden-file-input"
          onChange={(e) => {
            setFile(e.target.files?.[0] || null);
            setSummary(null);
            setRunId(null);
          }}
        />

        <div className="search_bar">

          {!file && (
            <img
              src={uploadIcon}
              className="upload-icon"
              onClick={() => fileInputRef.current?.click()}
            />
          )}
          {file && (
            <div className="file-row">
              <span className="file-name">{file.name}</span>
              <button className="delete-btn" onClick={removeFile}>✕</button>
            </div>
          )}

          {/* prompt-box*/}
          
          <div className="prompt-box">
            <ModelDropdown value={model} onChange={setModel} />
            {/*<div className="model">
              <select value={model} onChange={(e) => setModel(e.target.value)}>
              <option value="gemini-3.5-Flash">Gemini 3.5 Flash</option>
              <option value="gemini-3.1-pro">Gemini 3.1 pro</option>
              <option value="Gemini 3 Flash">Gemini 3 Flash</option>
              <option value="gemini-2.5-pro">Gemini 2.5 Pro</option>
              <option value="gemini-1.5-flash">Gemini 1.5 Flash</option>
              <option value="Deep Research Pro(Beta)">Deep Research Pro(Beta)</option>
            </select>
            </div>*/}
            <input
              type="text"
              placeholder="Give custom instructions"
              value={userPrompt}
              onChange={(e) => setUserPrompt(e.target.value)}
            />
          </div>
          {/* Run Icon */}
          <img
            src={runIcon}
            className={`run-icon ${!file || status === "Running..." ? "disabled" : ""}`}
            onClick={() => {
              if (!file || status === "Running...") return;
              runPipeline();
            }}
          />

        </div>

        {status && <p className="status">{status}</p>}
        {error && <p className="error">{error}</p>}

        {/* PROGRESS BAR */}
        {status === "Running..." && (
          <div className="progress-bar">
            <div style={{ width: `${progress}%` }} className="progress-fill" />
          </div>
        )}

        {/* LIVE LOGS */}
        {logs.length > 0 && (
          <div className="logs">
            {logs.map((log, i) => (
              <p key={i}>{log}</p>
            ))}
          </div>
        )}

        {/* SUMMARY */}
        {summary && (
          <div className="summary">
            <p>Total rows: {summary.total_rows}</p>
            <p>Healed rows: {summary.healed_rows}</p>
            <p>Quarantined rows: {summary.quarantined_rows}</p>

            <div className="actions">
              <button onClick={() => download("clean")}>Clean CSV</button>
              <button onClick={() => download("healed")}>Healed Rows</button>
              <button onClick={() => download("logs")}>Logs</button>
            </div>
          </div>
        )}
        <div className="bottom-bar">
            <div className="divider_2" />
            <p className="footer-text">This pipeline is AI driven, AI can make mistakes.</p>
        </div>
      </div>
    </div>
  );
}